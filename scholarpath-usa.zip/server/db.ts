import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { SCHOLARSHIP_CATEGORIES } from '../src/data/categories.ts';
import { SCHOLARSHIPS } from '../src/data/scholarships.ts';
import { UNIVERSITIES } from '../src/data/universities.ts';
import { EDITORIAL_GUIDES } from '../src/data/guides.ts';
import { hashPassword } from './security.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_PATH = path.join(DATA_DIR, 'scholarpath.db');
export const db = new DatabaseSync(DB_PATH);

db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin', 'editor')),
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    csrf_token TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS categories (
    slug TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    short_name TEXT NOT NULL,
    description TEXT NOT NULL,
    seo_title TEXT NOT NULL,
    seo_description TEXT NOT NULL,
    swatch_class TEXT NOT NULL,
    text_class TEXT NOT NULL,
    border_class TEXT NOT NULL,
    surface_class TEXT NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS universities (
    slug TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    short_name TEXT NOT NULL,
    initials TEXT NOT NULL,
    city TEXT NOT NULL,
    state TEXT NOT NULL,
    state_code TEXT NOT NULL,
    institution_type TEXT NOT NULL,
    acceptance_rate TEXT NOT NULL,
    avg_aid_package TEXT NOT NULL,
    undergrad_enrollment TEXT NOT NULL,
    website TEXT NOT NULL,
    overview TEXT NOT NULL,
    financial_aid_policy TEXT NOT NULL,
    is_sample_data INTEGER NOT NULL DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS scholarships (
    id TEXT PRIMARY KEY,
    slug TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    university_slug TEXT NOT NULL,
    university_name TEXT NOT NULL,
    state TEXT NOT NULL,
    state_code TEXT NOT NULL,
    category TEXT NOT NULL,
    secondary_categories_json TEXT NOT NULL DEFAULT '[]',
    degree_levels_json TEXT NOT NULL DEFAULT '[]',
    fields_of_study_json TEXT NOT NULL DEFAULT '[]',
    amount_display TEXT NOT NULL,
    amount_numeric INTEGER NOT NULL DEFAULT 0,
    coverage_summary TEXT NOT NULL,
    covers_tuition INTEGER NOT NULL DEFAULT 1,
    covers_housing INTEGER NOT NULL DEFAULT 0,
    covers_books INTEGER NOT NULL DEFAULT 0,
    includes_stipend INTEGER NOT NULL DEFAULT 0,
    renewable TEXT NOT NULL,
    deadline_iso TEXT NOT NULL,
    deadline_label TEXT NOT NULL,
    gpa_min REAL NOT NULL DEFAULT 3.0,
    featured INTEGER NOT NULL DEFAULT 0,
    is_sample_data INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'published' CHECK(status IN ('published', 'draft')),
    tags_json TEXT NOT NULL DEFAULT '[]',
    seo_title TEXT NOT NULL DEFAULT '',
    seo_description TEXT NOT NULL DEFAULT '',
    last_updated TEXT NOT NULL,
    overview TEXT NOT NULL,
    eligibility_json TEXT NOT NULL DEFAULT '[]',
    required_documents_json TEXT NOT NULL DEFAULT '[]',
    application_steps_json TEXT NOT NULL DEFAULT '[]',
    official_url TEXT NOT NULL,
    faqs_json TEXT NOT NULL DEFAULT '[]'
  );

  CREATE TABLE IF NOT EXISTS guides (
    slug TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    seo_title TEXT NOT NULL,
    seo_description TEXT NOT NULL,
    category_label TEXT NOT NULL,
    excerpt TEXT NOT NULL,
    author_name TEXT NOT NULL,
    author_role TEXT NOT NULL,
    author_bio TEXT NOT NULL,
    published_date TEXT NOT NULL,
    last_updated TEXT NOT NULL,
    read_minutes INTEGER NOT NULL DEFAULT 5,
    image_key TEXT NOT NULL DEFAULT 'readingRoom',
    custom_image_url TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'published' CHECK(status IN ('published', 'draft')),
    tags_json TEXT NOT NULL DEFAULT '[]',
    sections_json TEXT NOT NULL DEFAULT '[]',
    faqs_json TEXT NOT NULL DEFAULT '[]'
  );

  CREATE TABLE IF NOT EXISTS legal_pages (
    slug TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    seo_title TEXT NOT NULL,
    seo_description TEXT NOT NULL,
    sections_json TEXT NOT NULL,
    last_updated TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS site_settings (
    key TEXT PRIMARY KEY,
    value_json TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS media_assets (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    url TEXT NOT NULL,
    alt_text TEXT NOT NULL,
    category TEXT NOT NULL,
    width INTEGER NOT NULL DEFAULT 1280,
    height INTEGER NOT NULL DEFAULT 960,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS contact_messages (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    topic TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'new' CHECK(status IN ('new', 'reviewed', 'archived')),
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS newsletter_subscribers (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    role TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS deadline_reminders (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL,
    scholarship_slug TEXT NOT NULL,
    scholarship_title TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS backups (
    id TEXT PRIMARY KEY,
    created_by TEXT NOT NULL,
    summary_json TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
`);

export const DEFAULT_SETTINGS = {
  general: {
    brandName: 'ScholarPath USA',
    shortName: 'ScholarPath',
    tagline: 'Find Fully Funded and Partial Scholarships at U.S. Universities',
    contactEmail: 'editorial@scholarpathusa.example.com',
    advertisingEmail: 'partners@scholarpathusa.example.com',
    location: 'Boston, Massachusetts, USA',
    editorialTeamLead: 'Dr. Elena Morales, Ed.D.',
    ga4MeasurementId: 'G-XXXXXXXXXX',
    googleSiteVerification: 'YOUR_GOOGLE_SEARCH_CONSOLE_TOKEN',
    lastSiteAuditDate: '2026-11-15',
  },
  homepage: {
    heroEyebrow: 'U.S. University Scholarship Directory · 2026–2027 Cycle',
    heroTitle: 'Find Fully Funded and Partial Scholarships at U.S. Universities',
    heroSubtitle:
      'Search 14 funding categories across accredited American public and private universities. Compare tuition coverage, GPA thresholds, and deadlines side by side without paywalls.',
    featuredCount: 6,
    showHowItWorks: true,
    showTopUniversities: true,
    showLatestGuides: true,
    showNewsletter: true,
    showFaq: true,
  },
  menus: {
    primaryNav: [
      { label: 'Scholarships', to: '/scholarships' },
      { label: 'Universities', to: '/universities' },
      { label: 'Full Ride', to: '/scholarships/fully-funded' },
      { label: 'Guides', to: '/guides' },
      { label: 'About', to: '/about' },
    ],
    primaryCtaLabel: 'Eligibility Quiz',
    primaryCtaTo: '/quiz',
  },
  monetization: {
    enabled: false,
    showPreApprovalSlots: false,
    primaryNetwork: 'adsense',
    adsensePublisherId: 'ca-pub-0000000000000000',
    medianetCustomerId: '8CU000000',
    medianetSiteId: 'medianet-site-placeholder',
    revbitSiteId: 'revbit-site-placeholder-id',
    adsTxtContent: `# ScholarPath USA ads.txt configuration\n# Add your verified publisher lines after AdSense, Media.net, and Revbit approval.\n# google.com, pub-0000000000000000, DIRECT, f08c47fec0942fa0\n# media.net, 8CU000000, DIRECT\n# revbit.net, 000000, DIRECT\n`,
    slots: {
      header: {
        id: 'slot-header-leaderboard',
        enabled: true,
        network: 'adsense',
        slotCode: '1000000001',
        label: 'Advertisement',
        minHeightDesktop: 90,
        minHeightMobile: 50,
      },
      inContent: {
        id: 'slot-in-content-responsive',
        enabled: true,
        network: 'medianet',
        slotCode: '2000000002',
        label: 'Advertisement',
        minHeightDesktop: 250,
        minHeightMobile: 250,
      },
      sidebar: {
        id: 'slot-sidebar-rectangle',
        enabled: true,
        network: 'adsense',
        slotCode: '3000000003',
        label: 'Advertisement',
        minHeightDesktop: 250,
        minHeightMobile: 250,
      },
      footer: {
        id: 'slot-footer-banner',
        enabled: true,
        network: 'revbit',
        slotCode: '4000000004',
        label: 'Advertisement',
        minHeightDesktop: 90,
        minHeightMobile: 50,
      },
    },
  },
};

const DEFAULT_LEGAL_PAGES = [
  {
    slug: 'privacy-policy',
    title: 'Privacy Policy',
    seoTitle: 'Privacy Policy | ScholarPath USA',
    seoDescription:
      'Read the ScholarPath USA Privacy Policy covering Google AdSense, Media.net, Revbit advertising cookies, GDPR/CCPA rights, and analytics.',
    lastUpdated: '2026-11-15',
    sections: [
      {
        heading: '1. Overview & Information We Collect',
        body: 'ScholarPath USA respects the privacy of students, parents, educators, and visitors. You can browse our scholarship directory, eligibility quiz, and comparison tool without creating an account. We collect personal information only when you voluntarily provide it via contact, newsletter, or deadline reminder forms. Bookmarked scholarships, comparison trays, and Light/Dark preferences remain stored locally in your browser.',
      },
      {
        heading: '2. Google AdSense, Media.net, Revbit & Third-Party Advertising Vendors',
        body: 'When advertising is enabled on ScholarPath USA, third-party ad networks—including Google AdSense, Media.net, and Revbit—may use cookies, web beacons, or contextual signals to serve relevant advertisements. Google uses advertising cookies to serve ads based on prior visits to this website or other sites across the web. Users may opt out of personalized advertising via Google Ads Settings (https://www.google.com/settings/ads) or aboutads.info.',
      },
      {
        heading: '3. Consent Management (GDPR / CCPA / Google Consent Mode v2)',
        body: 'Optional analytics and advertising signals remain denied by default until you express your preference through our Cookie Consent dialog. You may withdraw or modify your consent at any time from the Cookie Policy page or footer.',
      },
      {
        heading: '4. Data Security & Retention',
        body: 'Form submissions and administrative credentials are protected with industry-standard password hashing, parameterized SQL queries, CSRF validation, and HTTPS transport encryption.',
      },
    ],
  },
  {
    slug: 'terms',
    title: 'Terms & Conditions',
    seoTitle: 'Terms & Conditions | ScholarPath USA',
    seoDescription:
      'Terms and conditions governing use of the ScholarPath USA university scholarship directory, comparison tool, and educational guides.',
    lastUpdated: '2026-11-15',
    sections: [
      {
        heading: '1. Acceptance of Terms',
        body: 'By accessing or using ScholarPath USA, you agree to comply with these Terms & Conditions and all applicable U.S. laws.',
      },
      {
        heading: '2. Educational Information Only',
        body: 'All scholarship listings, eligibility criteria, GPA benchmarks, deadlines, and financial aid articles are provided strictly for educational research. Using our quiz or bookmarking tools does not submit an application to any university.',
      },
      {
        heading: '3. Intellectual Property & Permissible Use',
        body: 'Original guides and curated summaries belong to ScholarPath USA. Counselors and students may share links for non-commercial advising; automated scraping or republication without consent is prohibited.',
      },
    ],
  },
  {
    slug: 'disclaimer',
    title: 'Disclaimer & Institutional Non-Affiliation Notice',
    seoTitle: 'Disclaimer & Data Notice | ScholarPath USA',
    seoDescription:
      'Important disclaimer: ScholarPath USA is an independent directory not affiliated with U.S. universities, FAFSA, or the federal government.',
    lastUpdated: '2026-11-15',
    sections: [
      {
        heading: '1. No University or Government Affiliation',
        body: 'ScholarPath USA is an independent private informational website. We are not affiliated with, endorsed by, or officially connected to any U.S. college, university, state higher education agency, Federal Student Aid (FAFSA), or the U.S. Department of Education.',
      },
      {
        heading: '2. Verification Responsibility',
        body: 'Universities regularly revise tuition amounts, GPA cutoffs, and deadlines. Always confirm final requirements on each sponsoring university’s official financial aid portal prior to applying.',
      },
      {
        heading: '3. Advertising Disclosure',
        body: 'When enabled, third-party advertisements from Google AdSense, Media.net, or Revbit are clearly labeled as advertisements and never influence editorial scholarship listings or quiz scoring.',
      },
    ],
  },
  {
    slug: 'cookie-policy',
    title: 'Cookie Policy',
    seoTitle: 'Cookie Policy | ScholarPath USA',
    seoDescription:
      'Learn how ScholarPath USA uses essential browser storage, Google Consent Mode v2, analytics, and advertising cookies.',
    lastUpdated: '2026-11-15',
    sections: [
      {
        heading: '1. Essential Storage (Always Active)',
        body: 'Strictly necessary browser storage preserves your Light/Dark mode selection, saved scholarships, side-by-side comparison tray, and cookie consent choice.',
      },
      {
        heading: '2. Analytics Cookies (Optional)',
        body: 'Analytics storage remains denied until you opt in. When enabled, privacy-configured Google Analytics 4 helps us monitor search usability and Core Web Vitals.',
      },
      {
        heading: '3. Advertising Cookies (Google AdSense, Media.net & Revbit)',
        body: 'When ad placements are enabled after approval, advertising cookies operate strictly according to your Consent Mode preferences.',
      },
    ],
  },
];

function seedDatabaseIfEmpty() {
  const userCount = (db.prepare('SELECT COUNT(*) as cnt FROM users').get() as { cnt: number }).cnt;
  if (userCount === 0) {
    const now = new Date().toISOString();
    const insertUser = db.prepare(
      'INSERT INTO users (id, name, email, password_hash, role, active, created_at) VALUES (?, ?, ?, ?, ?, 1, ?)'
    );
    insertUser.run(
      'usr_admin_01',
      'Dr. Elena Morales',
      'admin@scholarpathusa.example.com',
      hashPassword('ScholarAdmin2026!'),
      'admin',
      now
    );
    insertUser.run(
      'usr_editor_01',
      'Marcus Vance',
      'editor@scholarpathusa.example.com',
      hashPassword('ScholarEditor2026!'),
      'editor',
      now
    );
  }

  const catCount = (db.prepare('SELECT COUNT(*) as cnt FROM categories').get() as { cnt: number }).cnt;
  if (catCount === 0) {
    const stmt = db.prepare(`
      INSERT INTO categories (slug, name, short_name, description, seo_title, seo_description, swatch_class, text_class, border_class, surface_class, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    SCHOLARSHIP_CATEGORIES.forEach((c, idx) => {
      stmt.run(
        c.slug,
        c.name,
        c.shortName,
        c.description,
        c.seoTitle,
        c.seoDescription,
        c.swatchClass,
        c.textClass,
        c.borderClass,
        c.surfaceClass,
        idx
      );
    });
  }

  const uniCount = (db.prepare('SELECT COUNT(*) as cnt FROM universities').get() as { cnt: number }).cnt;
  if (uniCount === 0) {
    const stmt = db.prepare(`
      INSERT INTO universities (slug, name, short_name, initials, city, state, state_code, institution_type, acceptance_rate, avg_aid_package, undergrad_enrollment, website, overview, financial_aid_policy, is_sample_data)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    UNIVERSITIES.forEach((u) => {
      stmt.run(
        u.slug,
        u.name,
        u.shortName,
        u.initials,
        u.city,
        u.state,
        u.stateCode,
        u.institutionType,
        u.acceptanceRate,
        u.avgAidPackage,
        u.undergradEnrollment,
        u.website,
        u.overview,
        u.financialAidPolicy,
        u.isSampleData ? 1 : 0
      );
    });
  }

  const schCount = (db.prepare('SELECT COUNT(*) as cnt FROM scholarships').get() as { cnt: number }).cnt;
  if (schCount === 0) {
    const stmt = db.prepare(`
      INSERT INTO scholarships (
        id, slug, title, university_slug, university_name, state, state_code, category,
        secondary_categories_json, degree_levels_json, fields_of_study_json,
        amount_display, amount_numeric, coverage_summary, covers_tuition, covers_housing,
        covers_books, includes_stipend, renewable, deadline_iso, deadline_label,
        gpa_min, featured, is_sample_data, status, tags_json, seo_title, seo_description,
        last_updated, overview, eligibility_json, required_documents_json,
        application_steps_json, official_url, faqs_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'published', '[]', '', '', ?, ?, ?, ?, ?, ?, ?)
    `);
    SCHOLARSHIPS.forEach((s) => {
      stmt.run(
        s.id,
        s.slug,
        s.title,
        s.universitySlug,
        s.universityName,
        s.state,
        s.stateCode,
        s.category,
        JSON.stringify(s.secondaryCategories || []),
        JSON.stringify(s.degreeLevels),
        JSON.stringify(s.fieldsOfStudy),
        s.amountDisplay,
        s.amountNumeric,
        s.coverageSummary,
        s.coversTuition ? 1 : 0,
        s.coversHousing ? 1 : 0,
        s.coversBooks ? 1 : 0,
        s.includesStipend ? 1 : 0,
        s.renewable,
        s.deadlineISO,
        s.deadlineLabel,
        s.gpaMin,
        s.featured ? 1 : 0,
        s.isSampleData ? 1 : 0,
        s.lastUpdated,
        s.overview,
        JSON.stringify(s.eligibility),
        JSON.stringify(s.requiredDocuments),
        JSON.stringify(s.applicationSteps),
        s.officialUrl,
        JSON.stringify(s.faqs)
      );
    });
  }

  const guideCount = (db.prepare('SELECT COUNT(*) as cnt FROM guides').get() as { cnt: number }).cnt;
  if (guideCount === 0) {
    const stmt = db.prepare(`
      INSERT INTO guides (
        slug, title, seo_title, seo_description, category_label, excerpt,
        author_name, author_role, author_bio, published_date, last_updated,
        read_minutes, image_key, custom_image_url, status, tags_json, sections_json, faqs_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '', 'published', '[]', ?, ?)
    `);
    EDITORIAL_GUIDES.forEach((g) => {
      stmt.run(
        g.slug,
        g.title,
        g.seoTitle,
        g.seoDescription,
        g.categoryLabel,
        g.excerpt,
        g.authorName,
        g.authorRole,
        g.authorBio,
        g.publishedDate,
        g.lastUpdated,
        g.readMinutes,
        g.imageKey,
        JSON.stringify(g.sections),
        JSON.stringify(g.faqs)
      );
    });
  }

  const legalCount = (db.prepare('SELECT COUNT(*) as cnt FROM legal_pages').get() as { cnt: number }).cnt;
  if (legalCount === 0) {
    const stmt = db.prepare(`
      INSERT INTO legal_pages (slug, title, seo_title, seo_description, sections_json, last_updated)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    DEFAULT_LEGAL_PAGES.forEach((lp) => {
      stmt.run(
        lp.slug,
        lp.title,
        lp.seoTitle,
        lp.seoDescription,
        JSON.stringify(lp.sections),
        lp.lastUpdated
      );
    });
  }

  const settingsCount = (db.prepare('SELECT COUNT(*) as cnt FROM site_settings').get() as { cnt: number }).cnt;
  if (settingsCount === 0) {
    const now = new Date().toISOString();
    const stmt = db.prepare('INSERT INTO site_settings (key, value_json, updated_at) VALUES (?, ?, ?)');
    Object.entries(DEFAULT_SETTINGS).forEach(([k, val]) => {
      stmt.run(k, JSON.stringify(val), now);
    });
  }

  const mediaCount = (db.prepare('SELECT COUNT(*) as cnt FROM media_assets').get() as { cnt: number }).cnt;
  if (mediaCount === 0) {
    const now = new Date().toISOString();
    const stmt = db.prepare(
      'INSERT INTO media_assets (id, title, url, alt_text, category, width, height, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    );
    const defaults = [
      ['media_hero_campus', 'Campus Quad & Library Hero', '/src/assets/images/hero_campus_library_1794638342764.jpg', 'Diverse U.S. college students walking across a sunlit red-brick university quad toward the campus library', 'Hero', 1408, 768],
      ['media_graduation', 'Commencement Graduates', '/src/assets/images/students_graduation_success_1794638342911.jpg', 'Diverse graduating university students in navy and gold academic gowns celebrating scholarship completion on campus', 'Guides', 1280, 960],
      ['media_stem_lab', 'STEM Research Lab', '/src/assets/images/stem_research_lab_1794638342903.jpg', 'Diverse university STEM students collaborating at a sunlit laboratory bench with scientific instruments', 'STEM', 1280, 960],
      ['media_reading_room', 'Library Reading Room', '/src/assets/images/university_reading_room_1794638343996.jpg', 'Students studying in a sunlit American university library reading room with oak tables and brass lamps', 'Financial Aid', 1280, 960],
      ['media_counselor_essay', 'Counselor Essay Advising', '/src/assets/images/counselor_student_essay_1794638343904.jpg', 'High school senior reviewing scholarship application essays and financial aid portal with a college advisor', 'Essays', 1280, 960],
    ] as const;

    defaults.forEach(([id, title, url, alt, cat, w, h]) => {
      stmt.run(id, title, url, alt, cat, w, h, now);
    });
  }
}

seedDatabaseIfEmpty();

// Row mapper helpers
export function mapScholarshipRow(row: any) {
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    universitySlug: row.university_slug,
    universityName: row.university_name,
    state: row.state,
    stateCode: row.state_code,
    category: row.category,
    secondaryCategories: JSON.parse(row.secondary_categories_json || '[]'),
    degreeLevels: JSON.parse(row.degree_levels_json || '[]'),
    fieldsOfStudy: JSON.parse(row.fields_of_study_json || '[]'),
    amountDisplay: row.amount_display,
    amountNumeric: Number(row.amount_numeric),
    coverageSummary: row.coverage_summary,
    coversTuition: Boolean(row.covers_tuition),
    coversHousing: Boolean(row.covers_housing),
    coversBooks: Boolean(row.covers_books),
    includesStipend: Boolean(row.includes_stipend),
    renewable: row.renewable,
    deadlineISO: row.deadline_iso,
    deadlineLabel: row.deadline_label,
    gpaMin: Number(row.gpa_min),
    featured: Boolean(row.featured),
    isSampleData: Boolean(row.is_sample_data),
    status: row.status || 'published',
    tags: JSON.parse(row.tags_json || '[]'),
    seoTitle: row.seo_title || '',
    seoDescription: row.seo_description || '',
    lastUpdated: row.last_updated,
    overview: row.overview,
    eligibility: JSON.parse(row.eligibility_json || '[]'),
    requiredDocuments: JSON.parse(row.required_documents_json || '[]'),
    applicationSteps: JSON.parse(row.application_steps_json || '[]'),
    officialUrl: row.official_url,
    faqs: JSON.parse(row.faqs_json || '[]'),
  };
}

export function mapCategoryRow(row: any) {
  return {
    slug: row.slug,
    name: row.name,
    shortName: row.short_name,
    description: row.description,
    seoTitle: row.seo_title,
    seoDescription: row.seo_description,
    swatchClass: row.swatch_class,
    textClass: row.text_class,
    borderClass: row.border_class,
    surfaceClass: row.surface_class,
    sortOrder: Number(row.sort_order),
  };
}

export function mapUniversityRow(row: any) {
  return {
    slug: row.slug,
    name: row.name,
    shortName: row.short_name,
    initials: row.initials,
    city: row.city,
    state: row.state,
    stateCode: row.state_code,
    institutionType: row.institution_type,
    acceptanceRate: row.acceptance_rate,
    avgAidPackage: row.avg_aid_package,
    undergradEnrollment: row.undergrad_enrollment,
    website: row.website,
    overview: row.overview,
    financialAidPolicy: row.financial_aid_policy,
    isSampleData: Boolean(row.is_sample_data),
  };
}

export function mapGuideRow(row: any) {
  return {
    slug: row.slug,
    title: row.title,
    seoTitle: row.seo_title,
    seoDescription: row.seo_description,
    categoryLabel: row.category_label,
    excerpt: row.excerpt,
    authorName: row.author_name,
    authorRole: row.author_role,
    authorBio: row.author_bio,
    publishedDate: row.published_date,
    lastUpdated: row.last_updated,
    readMinutes: Number(row.read_minutes),
    imageKey: row.image_key,
    customImageUrl: row.custom_image_url || '',
    status: row.status || 'published',
    tags: JSON.parse(row.tags_json || '[]'),
    sections: JSON.parse(row.sections_json || '[]'),
    faqs: JSON.parse(row.faqs_json || '[]'),
  };
}

export function getAllSettings() {
  const rows = db.prepare('SELECT key, value_json FROM site_settings').all() as Array<{ key: string; value_json: string }>;
  const settings: any = structuredClone(DEFAULT_SETTINGS);
  rows.forEach((r) => {
    try {
      settings[r.key] = JSON.parse(r.value_json);
    } catch {
      // keep default
    }
  });
  return settings;
}
