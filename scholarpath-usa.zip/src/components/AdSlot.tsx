import { useAppContext } from '../context/AppContext';

type SlotPosition = 'header' | 'inContent' | 'sidebar' | 'footer';

interface AdSlotProps {
  position: SlotPosition;
  className?: string;
}

/**
 * Multi-Network Monetization Slot (Google AdSense, Media.net & Revbit)
 * Controlled completely via Admin Dashboard -> Monetization settings.
 * Reserves exact min-height when active to preserve CLS < 0.1 and clearly labels ads.
 */
export function AdSlot({ position, className = '' }: AdSlotProps) {
  const { settings } = useAppContext();
  const monetization = settings.monetization;
  const slot = monetization.slots[position];

  if (!slot || !slot.enabled) {
    return null;
  }

  if (!monetization.enabled && !monetization.showPreApprovalSlots) {
    return null;
  }

  const activeNetwork = slot.network || monetization.primaryNetwork;

  return (
    <aside
      aria-label={slot.label || 'Advertisement'}
      className={`w-full flex flex-col items-center justify-center border border-slate-200 dark:border-slate-800 bg-slate-100/70 dark:bg-slate-900/60 rounded-lg overflow-hidden px-3 py-2 ${className}`}
      style={{ minHeight: `${slot.minHeightDesktop}px` }}
      data-ad-network={activeNetwork}
      data-ad-slot={slot.id}
      data-ad-unit-code={slot.slotCode}
      data-adsense-client={monetization.adsensePublisherId}
      data-medianet-cid={monetization.medianetCustomerId}
      data-revbit-site={monetization.revbitSiteId}
    >
      <span className="text-[11px] uppercase tracking-wider text-slate-500 dark:text-slate-400">
        {slot.label || 'Advertisement'}
      </span>
      {monetization.enabled ? (
        <div
          id={slot.id}
          className="w-full flex-1 flex items-center justify-center text-xs text-slate-500 dark:text-slate-400"
        >
          {/* Live network container ready for AdSense (<ins class="adsbygoogle">), Media.net, or Revbit */}
        </div>
      ) : (
        <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">
          Reserved responsive placement ({activeNetwork} · unit {slot.slotCode})
        </p>
      )}
    </aside>
  );
}
