export interface AdSlotConfig {
  id: string;
  label: string;
  minHeightDesktop: number;
  minHeightMobile: number;
}

export const siteConfig = {
  brandName: 'ScholarPath USA',
  shortName: 'ScholarPath',
  tagline: 'Find Fully Funded and Partial Scholarships at U.S. Universities',
  siteUrl:
    typeof window !== 'undefined'
      ? window.location.origin
      : process.env.APP_URL || 'https://scholarpathusa.example.com',
  contactEmail: 'editorial@scholarpathusa.example.com',
  advertisingEmail: 'partners@scholarpathusa.example.com',
  location: 'Boston, Massachusetts, USA',
  foundedYear: 2024,
  editorialTeamLead: 'Dr. Elena Morales, Ed.D.',
  lastSiteAuditDate: '2026-11-01',

  analytics: {
    ga4MeasurementId: 'G-XXXXXXXXXX',
    googleSiteVerification: 'YOUR_GOOGLE_SEARCH_CONSOLE_TOKEN',
  },

  /**
   * AdSense & Revbit Readiness Configuration
   * Keep `enabled: false` until domain approval is granted by Google AdSense / Revbit.
   * Flipping `enabled: true` activates non-intrusive, CLS-safe ad containers across the site.
   */
  ads: {
    enabled: false,
    showPreApprovalSlots: false,
    primaryNetwork: 'adsense' as 'adsense' | 'revbit',
    adsensePublisherId: 'ca-pub-0000000000000000',
    revbitSiteId: 'revbit-site-placeholder-id',
    slots: {
      header: {
        id: 'slot-header-leaderboard',
        label: 'Advertisement',
        minHeightDesktop: 90,
        minHeightMobile: 50,
      },
      inContent: {
        id: 'slot-in-content-responsive',
        label: 'Sponsored Resource',
        minHeightDesktop: 250,
        minHeightMobile: 250,
      },
      sidebar: {
        id: 'slot-sidebar-rectangle',
        label: 'Advertisement',
        minHeightDesktop: 250,
        minHeightMobile: 250,
      },
      footer: {
        id: 'slot-footer-banner',
        label: 'Advertisement',
        minHeightDesktop: 90,
        minHeightMobile: 50,
      },
    } satisfies Record<string, AdSlotConfig>,
  },
} as const;
